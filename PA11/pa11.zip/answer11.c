#include <stdio.h>
#include <stdlib.h>
#include "answer11.h"

HuffNode * HuffNode_create(int value)
{
	HuffNode * huff = malloc(sizeof(HuffNode)); 
	if (huff == NULL) return NULL;
	else {
		huff->value = value;
		huff->left = NULL;
		huff->right = NULL;
	}
	return huff;
}

void HuffNode_destroy(HuffNode * tree)
{
	if (tree == NULL) return;
	HuffNode_destroy(tree->left);
	HuffNode_destroy(tree->right);
	free(tree);
}

Stack * Stack_create()
{
	Stack * st =  malloc(sizeof(Stack));
	if (st == NULL) return NULL;
	else {
		st->head = NULL;
		return st;
	}
}

void Stack_destroy(Stack * stack)
{
	if (stack != NULL) {	
		while(!Stack_isEmpty(stack))
		{    
			HuffNode_destroy(Stack_popFront(stack));    
		}
		free(stack);
	}
}

int Stack_isEmpty(Stack * stack)
{
	if (stack->head == NULL) return 1;
	return 0;
}

HuffNode * Stack_popFront(Stack * stack)
{
	HuffNode * huff = NULL;
	StackNode * new = NULL;
	if (stack == NULL) return NULL;
	if (Stack_isEmpty(stack) != 0) stack->head = new;
	else {   
		huff = (stack->head)->tree;
		new = (stack->head)->next;
		free(stack->head);
		stack->head = new;
	}

	return huff;
}

void Stack_pushFront(Stack * stack, HuffNode * tree)
{
	StackNode * st = malloc(sizeof(StackNode));
	if (st == NULL) printf("error!");
	else {
		st->tree = tree;
		st->next = stack->head;
		stack->head = st;
	}
}

void Stack_popPopCombinePush(Stack * stack)
{
	HuffNode * huff1, * huff2, * newhuff;
	huff1 = Stack_popFront(stack);
	huff2 = Stack_popFront(stack);

	if (huff1 == NULL && huff2 == NULL) newhuff = NULL;
	else if (huff1 == NULL)	newhuff = huff2;
	else if (huff2 == NULL) newhuff = huff1;
	else {
		int valuesum = 0;
		valuesum += huff1->value + huff2->value;
		newhuff = HuffNode_create(valuesum);
		if (newhuff != NULL) {
			if (huff1 < huff2) {
				newhuff->left = huff1;
				newhuff->right = huff2;
			}
			else {
				newhuff->left = huff2;
				newhuff->right = huff1;
			}
		}
		else {
			newhuff->left = NULL;
			newhuff->right = NULL;
		}
	}
	Stack_pushFront(stack, newhuff);
}

HuffNode * HuffTree_readTextHeader(FILE * fp)
{
	HuffNode * readt = NULL;
	Stack * st = Stack_create();

	char p;
	char c;
	while (!feof(fp))
	{
		p = fgetc(fp);
		if (p == '1') {
			c = fgetc(fp);
			Stack_pushFront(st, HuffNode_create(c));
		}
		else if (p == '0')
		{
			if ((st->head)->next != NULL) Stack_popPopCombinePush(st);
			else {
				readt = Stack_popFront(st);
				Stack_destroy(st);
				return readt;
			}
		}
	}
	readt = Stack_popFront(st);
	Stack_destroy(st);
	return readt;
}

HuffNode * HuffTree_readBinaryHeader(FILE * fp)
{
	Stack * stack = Stack_create();
	HuffNode * readt = NULL;
	unsigned char current;
	unsigned char mask = 0x01<<7;
	unsigned char pos = 0;

	while(!feof(fp))
	{
		unsigned char bi = 0x00;
		if (pos == 0) fread(&current, sizeof(unsigned char), 1, fp);
		bi <<= 1; 
		bi |= ((mask & (current)<<pos))>>7;
		pos = (pos + 1) % 8;
		if (bi == 0) {
			if ((stack->head)->next != NULL) Stack_popPopCombinePush(stack);
			else {
				readt = Stack_popFront(stack);
				Stack_destroy(stack);
				return readt;
			}			
		}
		else if (bi == 1) {
			unsigned char c = 0x00;
			int ind;
			for (ind = 0; ind < 8; ind++) {
				if (pos == 0) fread(&current, sizeof(unsigned char), 1, fp);
				c <<= 1; 
				c |= ((mask & (current)<<pos))>>7;
				pos = (pos + 1) % 8;
			}
			Stack_pushFront(stack, HuffNode_create(c));
		}
	}
	readt = Stack_popFront(stack);
	Stack_destroy(stack);
	return readt;
}

